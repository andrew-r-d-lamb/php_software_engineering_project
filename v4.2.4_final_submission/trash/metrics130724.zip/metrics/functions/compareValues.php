<?php
    /**
     * function used by usort to order array
     * 
     * @param array    $a array to be sorted
     * @param function $b callable function for usort
     * 
     * @return void 
     */
    function compareValues($a, $b)
    {
        //SORT RESULTS BY RANK
        //Code derived from: http://ie1.php.net/usort
        
        //Compare based on element 3 which is storing the score
        if ($a[3] === $b[3]) {
            return 0; //same priority
        } elseif ($a[3] > $b[3]) {
            return -1; //a has higher priority than b
        } else {
            return 1; //b has higher priority than a
        }
    }
    
?>
