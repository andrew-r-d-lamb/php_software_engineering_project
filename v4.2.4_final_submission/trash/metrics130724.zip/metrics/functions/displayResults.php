<?php
/**
 * Function to display some of the contents of an array passed to it
 * 
 * PHP version 5
 * 
 * @category PHP
 * @package  PHP_Metasearch_Engine
 * @author   Andrew Lamb <andrew.r.d.lamb@gmail.com>
 * @license  http://opensource.org/licenses/gpl-license.php GNU Public License
 * @link     http://csserver.ucd.ie/~01421662/
 */
/**
 * Function takes in an array by value, and displays contents
 * 
 * @param array $arrayName array to display
 * 
 * @return void
 */
function displayResults($arrayName) 
{
    //Display Non-aggregated results:  
    if ($_POST['result_type']==='Non-Aggregated') {
        //Loop through Array and check that values have been stored in it:
        foreach ($arrayName as $key => $value) {
            //    echo "<p>Array Position: " . $key 
            //    . "<br />URL: " . $value[0] 
            //    . "<br />Title: " . $value[1] 
            //    . "<br />Snippet: " . $value[2] 
            //    . "<br />Rank:" . $value[3] . "</p>";
            echo "<p>Original URL: " . $value[5] 
                //. "<br />Comparison URL: " . $value[0] 
                . "<br />Rank/Score: " . number_format($value[3], 2, '.', '') 
                //. "<br />Snippet: " . $value[2] 
                . "</p>";
        }
            //var_dump($arrayName);
    } else {
        //Display Aggregated results:
        foreach ($arrayName as $key => $value) {
            //    echo "<p>Array Position: " . $key 
            //    . "<br />URL: " . $value[0] 
            //    . "<br />Title: " . $value[1] 
            //    . "<br />Snippet: " . $value[2] 
            //    . "<br />Rank:" . $value[3] . "</p>";
            echo "<p>Original URL: " . $value[4] 
                //. "<br />Comparison URL: " . $value[0] 
                . "<br />Rank/Score: " . number_format($value[3], 2, '.', '') 
                //. "<br />Snippet: " . $value[2]
                . "</p>";
        }
    }
  
}

?>
