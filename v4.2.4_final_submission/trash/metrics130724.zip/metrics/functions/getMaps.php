<?php
function getMaps(&$arrayToPopulate, $dataArray) 
{
    foreach ($dataArray as $key => $value) {
        $mapSum = 0;
        foreach ($dataArray[$key] as $subKey => $subValue) {
            $mapSum = $mapSum + $subValue[9];
            //echo $mapSum . "<br />";
        }
        $mapSum = $mapSum / 50;
        $arrayToPopulate[] = array($key, $mapSum);
    }
}?>