<?php

//$fileName = "civil right movement.txt";

/*
$aggregated = array();
readFromFile($aggregated, "bingResults", $fileName);
print_r($aggregated);
*/

/*
$weighted = array();
readFromFile($weighted, "bingResults", $fileName);
print_r($weighted);
*/

function readFromFile(&$resultSet, $directoryName, $fileName) 
{
    $fp = fopen("$directoryName/$fileName", 'r'); //open file
    $fileContents = fread($fp, filesize("$directoryName/$fileName"));
    $resultSet = unserialize($fileContents);
    fclose($fp);
}
?>
